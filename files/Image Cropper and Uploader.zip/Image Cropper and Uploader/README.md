# Image Cropper Uploader

Aim of this project is to pick a image of 1024 X 1024 image

Image should be of following extensions accepted:

+ jpg
+ jpeg
+ png

Pick the image and show a web page with all the desired sizes of images which are as follows:

+ 380*380
+ 365*212
+ 365*450
+ 755*450

Once the images are displayed of the above sizes, We can choose edit the images and crop as per our selection and upload to image service.

Result will be provided as a URL which is public to be accessed.

Application is being developed in *NodeJs* 

Following Pacakges are used for features:
+ Cropper Js - For Crop functionality
+ Cloudinary - For Image Upload Service
+ Webpack - For JS Minify

Ahead Plans:
+ Queue Implementation
+ Server Side Storage Removal