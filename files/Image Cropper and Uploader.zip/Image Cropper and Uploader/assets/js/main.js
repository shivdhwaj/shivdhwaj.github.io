var cropper = "";
$(function () {        
    $("#preview").hide();
    $("#photoInput").change(function (e) {
        var file, img, flag = false, allowedHeight = 1024, allowedWidth = 1024;
        if ((file = this.files[0])) {
            img = new Image();
            img.onload = function () {
                if(!(this.width == allowedWidth && this.height == allowedHeight)){
                    alert('Please Upload a image of dimension '+allowedWidth+' * '+allowedHeight);
                    $("#photoInput").val('');
                    $("#preview").hide();
                }else{
                    $("#preview").show();
                }
            };
            img.src = _URL.createObjectURL(file); 
            fileCheckAndPlotter($(this),e);
            $("#preview").hide();
        }else{
            alert("This browser does not support FileReader.");
        }
        ;       
    });
});

var _URL = window.URL || window.webkitURL;

$(document).on( "click", ".editPic", function() {
    console.log($(this).data("id"));
    $(this).text("Upload Pic").removeClass("editPic").addClass("uploadPic");
    editPic($(this).data("id"));
});

$(document).on( "click", ".uploadPic", function() {
    // alert($(this).data("id"));
    $(this).attr('id',$(this).data("id")+"_url").text("Uploading...").removeClass("uploadPic").prop("disabled",true);
    getCanvasImage($(this).data("id"));
    $(this).removeClass("btn btn-primary").addClass($(this).data("id")+"_url");
});

function getCanvasImage(picId){
    cropper.getCroppedCanvas().toBlob((blob) => {
        const formData = new FormData();
        formData.append('croppedImage'+picId, blob);
        $.ajax('/api/photo', {
          method: "POST",
          data: formData,
          processData: false,
          contentType: false,
          success(resp) {
            cropper.disable();
            document.getElementById(picId+"_url").innerHTML = "Image Uploaded Successfully at <a href='"+resp+"' target='_blank'>Click Here</a>";
          },
          error(err) {
            document.getElementById(picId+"_url").innerHTML = "Error Occured while Uploading"
            alert("Upload error");
          },
        });
    });
}

function fileCheckAndPlotter(data, e){
    var sizes = ["380*380", "365*212", "365*450", "755*450"];
    var regex = /^([a-zA-Z0-9\s_\\.\-:])+(.jpg|.jpeg|.png)$/;
    if (regex.test(data.val().toLowerCase())) {
        if (typeof (FileReader) != "undefined") {
            var reader = new FileReader();
            document.getElementById('plotAllSizesHtmlData').innerHTML = "";
            reader.onload = function (e) {
                sizes.forEach(plotHtmlWithAllSizes.bind(null, e));
            }
            reader.readAsDataURL(data[0].files[0]);
            $("#preview").show();
        }else {
            alert("This browser does not support FileReader.");
        }
    }else{
        alert("Supported Formats: .jpg, .jpeg, .gif, .png, .bmp");
    }
}

function editPic(picId){
    if(picId == "")
        picId = "dvPreview755*450Img";
    const image = document.getElementById(picId);
    cropper = new Cropper(image, {
        // aspectRatio: 16 / 9,
        crop(event) {
            // console.log(picId+" X axis "+event.detail.x);
            // console.log(picId+" Y axis "+event.detail.y);
            // console.log(picId+" Width "+event.detail.width);
            // console.log(picId+" Height "+event.detail.height);
            // console.log(picId+" Rotate "+event.detail.rotate);
            // console.log(picId+" scaleX "+event.detail.scaleX);
            // console.log(picId+" scaleY "+event.detail.scaleY);
        },
    });
}

function plotHtmlWithAllSizes(e, value, index, array) {
    var widtheight = value.split("*");
    var htmlData = 
        '<div>'+
            '<div id="preview'+value+'">'+
                '<label>Image in dimension of '+value+'</label><br/>'+
                '<img id="dvPreview'+value+'Img" src="'+e.target.result+'" height="'+widtheight[0]+'" width="'+widtheight[1]+'"  />'+
            '</div>'+
            '<div class="pad15">'+
                // '<input class="btn btn-primary" type="submit" name="submit" id="btnSubmit" value="'+value+'"/>&nbsp;&nbsp;'+
                '<div class="btn btn-primary editPic" data-id="dvPreview'+value+'Img">Edit Pic</div>'+
            '</div>'+
        '</div>';
    htmlData = htmlData + "<br>";
    document.getElementById('plotAllSizesHtmlData').innerHTML +=htmlData;
}