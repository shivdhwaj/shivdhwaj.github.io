module.exports = Object.freeze({
    cloudinary: {
        api_key: 'YOUR CLOUDINARY API KEY', 
        api_secret: 'YOUR CLOUDINARY API SECRET KEY' ,
        cloud_name: 'YOU CLOUDINARY FOLDER'
    }
});