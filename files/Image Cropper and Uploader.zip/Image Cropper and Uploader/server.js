var express =   require("express");
var multer  =   require('multer');
var app         =   express();
const mime = require('mime');
var cloudinary = require('cloudinary');
var constants = require('./constants');
var fs = require('fs');

cloudinary.config({ 
  cloud_name: constants.cloudinary.cloud_name, 
  api_key: constants.cloudinary.api_key, 
  api_secret: constants.cloudinary.api_secret 
});

var storage =   multer.diskStorage({
  destination: function (req, file, callback) {
    callback(null, './uploads');
  },
  filename: function (req, file, callback) {
    callback(null, file.fieldname + '-' + Date.now()+ '.'+mime.getExtension(file.mimetype));
  }
});

var upload = multer({ storage : storage}).any();

app.get('/',function(req,res){
  res.sendFile(__dirname + "/index.html");
});

app.get('/favicon.ico',function(req,res){
  res.sendFile(__dirname + "/favicon.ico");
});

app.get('/main.css',function(req,res){
  res.sendFile(__dirname + "/main.css");
});

app.get('/dist/bundle.js',function(req,res){
  res.sendFile(__dirname + "/dist/bundle.js");
});

app.post('/api/photo',function(req,res){
  upload(req,res,function(err) {
    if(err) {
      return res.end("Error uploading file.");
    }
    cloudinary.v2.uploader.upload(req.files[0].path, function(error, result) {
      if(error){
        console.log(error);
        res.status(500).send("Error");
      }else{
        fs.unlink(req.files[0].path, function (err) {
          if (err) 
            console.log(err);
          else
            console.log(req.files[0].path+ ' File deleted!');
        });
        res.end(result.url);
      }
    });
  });
});

var port = 5000;
if(process.env.PORT)
  port = process.env.PORT;

app.listen(port,function(){
  console.log("Working on port "+port);
  console.log("Open this on Browser: http://localhost:"+port+"/");
});
